<div align="center">

![Practical Mini Projects 封面](assets/cover.png)

# Practical Mini Projects｜三个可复制的小项目

一个项目解决一个明确问题：**选择方案、检查数据、巡检链接**。每个目录都能单独运行，带示例、测试和对局限的说明。

[项目总览](#项目总览) · [快速开始](#快速开始) · [如何用于简历](#如何用于简历)

</div>

## 项目总览

| 项目 | 具体场景 | 你能检查的能力 | 打开 |
| --- | --- | --- | --- |
| **Decision Notebook** | 两周内要选择先做哪种求职作品 | 定义问题、调整权重、展示依据、不确定时暂缓结论 | [演示与源码](projects/decision-notebook/README.md) |
| **CSV Lens** | 订单 CSV 交给分析师前先找出错行 | 解析边界、定位缺失与重复、导出可复核的问题清单 | [演示与源码](projects/csv-quality-check/README.md) |
| **Link Auditor** | 帮助中心搬迁后核查关键链接 | 网络错误处理、`HEAD` 回退、离线可重复测试 | [演示与源码](projects/link-auditor/README.md) |

![Decision Notebook 页面截图](projects/decision-notebook/assets/demo-desktop.png)

> **真实性说明**：仓库中的求职情境、订单记录和演示网站均为模拟材料。测试通过只说明这些程序在所测条件下工作，不代表真实用户调研或业务成果。

## 快速开始

### 1. 决策记录本

```bash
cd projects/decision-notebook
python -m http.server 8000
```

打开 `http://localhost:8000`，修改权重或清空依据，观察结论如何变化。运行 `npm test` 检查判断规则。

### 2. CSV 数据体检

```bash
cd projects/csv-quality-check
python -m http.server 8001
```

打开 `http://localhost:8001`，页面会加载合成订单样本。可上传自己的 UTF-8 CSV，选择唯一标识列并下载报告。运行 `npm test` 检查解析器。

### 3. 链接巡检

```bash
cd projects/link-auditor
python demo.py
python -m unittest discover -s tests -v
```

演示脚本只访问本机临时站点，会生成 `demo-report.csv`。检查自己的链接时使用 `python link_auditor.py urls.txt --output report.csv`。

需要 Python 3.10+；两个网页的自动测试需要 Node.js 20+。网页没有第三方依赖。每个目录可独立复制。

## 为什么这样组织

这三个项目分别从**判断、数据、执行**切入，但使用相同的展示顺序：

```text
真实场景 → 可运行的最小功能 → 可核对的输入输出 → 测试 → 适用边界
```

仓库故意没有加入登录系统、数据库或大模型调用。它们会增加维护成本，却不会让这些小场景的核心问题更清楚。详情见各项目 README 和 [Decision Notebook 的设计取舍](projects/decision-notebook/docs/DECISIONS.md)。

## 如何用于简历

建议先运行每个项目，选择与你投递岗位最相关的一个，亲自修改场景或功能并留下真实记录。面试时能展示：问题是什么、试过哪些方案、为什么这样实现、如何验证、还有什么没解决。

可以参考这样的结构写一条经历，**只填真实内容**：

> 针对【你实际遇到的场景】，实现【你亲自完成的功能】；通过【真实测试或使用反馈】验证【结果】，并记录【具体取舍与局限】。

不要把仓库里的模拟订单、演示评分或本机链接检查写成业务业绩。

## 仓库结构

```text
assets/                 仓库封面
projects/
  decision-notebook/    交互式决策记录本
  csv-quality-check/    浏览器端 CSV 体检
  link-auditor/         Python 链接巡检 CLI
.github/workflows/      三个项目的自动测试
```

## License

[MIT](LICENSE)
