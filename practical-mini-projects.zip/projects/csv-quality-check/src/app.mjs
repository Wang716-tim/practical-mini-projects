import { inspectCsv, parseCsv, issuesToCsv } from './csv.mjs';

const $ = (selector) => document.querySelector(selector);
const labels = {
  'parse-error': '格式错误',
  'empty-header': '空列名',
  'duplicate-header': '重复列名',
  'column-count': '列数不一致',
  'duplicate-key': '重复主键',
  'missing-value': '缺失值',
};
let currentText = '';
let currentReport = null;

function cell(text, className = '') {
  const td = document.createElement('td');
  td.textContent = String(text ?? '');
  if (className) td.className = className;
  return td;
}

function setStatus(message, error = false) {
  $('#status').textContent = message;
  $('#status').classList.toggle('error', error);
}

function render(report) {
  currentReport = report;
  $('#row-count').textContent = String(report.dataRows);
  $('#column-count').textContent = String(report.headers.length);
  $('#issue-count').textContent = String(report.issues.length);
  setStatus(report.issues.length ? `找到 ${report.issues.length} 个待复核项。请逐行核对，工具不会修改原始文件。` : '未发现当前规则覆盖的问题。仍需检查业务含义与数据来源。');
  $('#download-issues').disabled = report.issues.length === 0;
  const body = $('#issue-list');
  body.replaceChildren();
  for (const issue of report.issues.slice(0, 50)) {
    const row = document.createElement('tr');
    const type = cell(labels[issue.type] || issue.type);
    type.className = 'issue-type-cell';
    const badge = document.createElement('span');
    badge.className = 'issue-type';
    badge.textContent = labels[issue.type] || issue.type;
    type.replaceChildren(badge);
    row.append(cell(issue.row), type, cell(issue.column || '—'), cell(issue.message));
    body.append(row);
  }
  if (!report.issues.length) {
    const row = document.createElement('tr');
    const empty = cell('当前规则下暂无问题。');
    empty.colSpan = 4;
    row.append(empty);
    body.append(row);
  }
  $('#table-note').textContent = report.issues.length > 50
    ? `页面只显示前 50 项；下载报告包含全部 ${report.issues.length} 项。`
    : '行号对应原始文件；带引号的多行字段以记录开始的物理行号定位。';
}

function refreshKeyOptions(headers) {
  const select = $('#key-column');
  select.replaceChildren(new Option('不检查重复值', ''));
  for (const header of headers) if (header.trim()) select.add(new Option(header, header));
  const likelyKey = headers.find((header) => /(^id$|_id$|编号|订单号)/i.test(header));
  select.value = likelyKey || '';
}

function analyze() {
  try {
    render(inspectCsv(currentText, { keyColumn: $('#key-column').value || null }));
  } catch (error) {
    setStatus(error.message, true);
  }
}

function loadText(text, filename) {
  currentText = text;
  $('#file-label').textContent = filename;
  refreshKeyOptions(parseCsv(text).headers);
  analyze();
}

$('#csv-file').addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) {
    setStatus('文件超过 2 MB。请拆分后再检查。', true);
    return;
  }
  try { loadText(await file.text(), file.name); }
  catch { setStatus('文件读取失败。请确认文件可访问，并使用 UTF-8 编码。', true); }
});

$('#key-column').addEventListener('change', analyze);

$('#load-sample').addEventListener('click', async () => {
  try {
    const response = await fetch('sample/orders.csv');
    if (!response.ok) throw new Error('无法加载示例文件');
    loadText(await response.text(), '示例订单数据');
    $('#csv-file').value = '';
  } catch {
    setStatus('示例加载失败。请通过本地静态服务器打开页面，或选择自己的 CSV 文件。', true);
  }
});

$('#download-issues').addEventListener('click', () => {
  if (!currentReport?.issues.length) return;
  const blob = new Blob([issuesToCsv(currentReport.issues)], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'csv-lens-issues.csv';
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

$('#load-sample').click();
