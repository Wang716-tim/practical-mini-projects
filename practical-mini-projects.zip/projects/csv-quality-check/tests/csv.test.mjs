import test from 'node:test';
import assert from 'node:assert/strict';
import { parseCsv, inspectCsv, issuesToCsv } from '../src/csv.mjs';

test('解析带逗号、换行和双引号的 CSV 字段', () => {
  const parsed = parseCsv('id,note\r\n1,"hello,\nworld"\r\n2,"say ""hi"""');
  assert.deepEqual(parsed.headers, ['id', 'note']);
  assert.deepEqual(parsed.rows, [['1', 'hello,\nworld'], ['2', 'say "hi"']]);
  assert.deepEqual(parsed.errors, []);
});

test('检查缺失值、主键重复和列数不一致，并保留行号', () => {
  const report = inspectCsv('id,name\n1,Alice\n1,\n3', { keyColumn: 'id' });
  assert.equal(report.dataRows, 3);
  assert.deepEqual(report.issues.map((issue) => [issue.type, issue.row]), [
    ['duplicate-key', 3],
    ['missing-value', 3],
    ['column-count', 4],
    ['missing-value', 4],
  ]);
});

test('空主键不会被误判为重复，空列名会被指出', () => {
  const report = inspectCsv('id,\n,A\n,B', { keyColumn: 'id' });
  assert.equal(report.issues.filter((issue) => issue.type === 'duplicate-key').length, 0);
  assert.equal(report.issues.filter((issue) => issue.type === 'empty-header').length, 1);
});

test('未闭合的引号给出可定位错误', () => {
  const parsed = parseCsv('id,name\n1,"broken');
  assert.match(parsed.errors[0].message, /引号/);
  assert.equal(parsed.errors[0].row, 2);
});

test('导出的问题 CSV 能正确转义逗号和引号', () => {
  const csv = issuesToCsv([{ type: 'missing-value', row: 2, column: 'note', message: '值为 "空", 请核对' }]);
  assert.match(csv, /"值为 ""空"", 请核对"/);
});
