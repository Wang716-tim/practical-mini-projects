import { evaluateDecision, formatReport } from './decision.mjs';
import { sampleDecision } from './sample.mjs';

const storageKey = 'decision-notebook-demo-v1';
const $ = (selector) => document.querySelector(selector);
const copySample = () => structuredClone(sampleDecision);

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (saved?.criteria?.length === sampleDecision.criteria.length && saved?.options?.length === sampleDecision.options.length) {
      evaluateDecision(saved.criteria, saved.options);
      return saved;
    }
  } catch {
    // Private browsing or malformed older state: use the bundled example.
  }
  return copySample();
}

let state = loadState();
let selectedId = state.options[0].id;

function saveState() {
  try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* The demo also works without storage. */ }
}

function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function renderCriteria() {
  const container = $('#criteria-controls');
  container.replaceChildren();
  state.criteria.forEach((criterion) => {
    const row = node('div', 'criterion');
    const top = node('div', 'criterion-top');
    const label = node('label', '', criterion.label);
    const id = `weight-${criterion.id}`;
    label.htmlFor = id;
    const output = node('output', '', String(criterion.weight));
    output.htmlFor = id;
    top.append(label, output);
    const hint = node('p', 'criterion-hint', criterion.hint);
    const input = node('input');
    Object.assign(input, { id, type: 'range', min: '1', max: '5', step: '1', value: String(criterion.weight) });
    input.setAttribute('aria-label', `${criterion.label}权重`);
    input.addEventListener('input', () => {
      criterion.weight = Number(input.value);
      output.textContent = input.value;
      saveState();
      renderResults();
      renderConclusion();
    });
    row.append(top, hint, input);
    container.append(row);
  });
}

function renderResults() {
  const result = evaluateDecision(state.criteria, state.options);
  $('#result-count').textContent = `${result.ranked.length} OPTIONS`;
  const container = $('#option-list');
  container.replaceChildren();
  result.ranked.forEach((option, index) => {
    const button = node('button', 'option-card');
    button.type = 'button';
    button.setAttribute('aria-pressed', String(option.id === selectedId));
    button.setAttribute('aria-label', `查看${option.name}的评分依据`);
    const number = node('span', 'option-rank', String(index + 1).padStart(2, '0'));
    const description = node('span');
    description.append(
      node('span', 'option-name', option.name),
      node('span', 'option-summary', option.summary),
      node('span', 'option-coverage', `证据覆盖率 ${Math.round(option.coverage * 100)}%`),
    );
    const score = node('span', 'option-score', option.score.toFixed(1));
    score.append(node('small', '', ' / 5'));
    button.append(number, description, score);
    button.addEventListener('click', () => {
      selectedId = option.id;
      renderResults();
      renderEvidence();
    });
    container.append(button);
  });
}

function renderEvidence() {
  const option = state.options.find((item) => item.id === selectedId) || state.options[0];
  $('#selected-summary').textContent = `${option.name}：${option.summary}`;
  const container = $('#evidence-editor');
  container.replaceChildren();
  state.criteria.forEach((criterion) => {
    const entry = option.scores[criterion.id];
    const row = node('div', 'evidence-item');
    const head = node('div', 'score-head');
    const scoreId = `score-${option.id}-${criterion.id}`;
    const label = node('label', '', criterion.label);
    label.htmlFor = scoreId;
    const output = node('output', '', `${entry.value}/5`);
    output.htmlFor = scoreId;
    head.append(label, output);
    const slider = node('input');
    Object.assign(slider, { id: scoreId, type: 'range', min: '0', max: '5', step: '1', value: String(entry.value) });
    slider.setAttribute('aria-label', `${option.name}的${criterion.label}分数`);
    slider.addEventListener('input', () => {
      entry.value = Number(slider.value);
      output.textContent = `${entry.value}/5`;
      saveState();
      renderResults();
      renderConclusion();
    });
    const evidenceId = `evidence-${option.id}-${criterion.id}`;
    const evidenceLabel = node('label', 'visually-hidden', `${option.name}的${criterion.label}依据`);
    evidenceLabel.htmlFor = evidenceId;
    const textarea = node('textarea');
    textarea.id = evidenceId;
    textarea.value = entry.evidence;
    textarea.placeholder = '写下可核对的依据；没有依据可以留空。';
    textarea.addEventListener('input', () => {
      entry.evidence = textarea.value;
      saveState();
      renderResults();
      renderConclusion();
    });
    row.append(head, slider, evidenceLabel, textarea);
    container.append(row);
  });
}

function renderConclusion() {
  const result = evaluateDecision(state.criteria, state.options);
  const box = $('#conclusion');
  box.replaceChildren();
  let label, name, explanation;
  if (result.status === 'ready') {
    label = 'CURRENT DIRECTION';
    name = result.recommendation.name;
    explanation = `当前领先 ${result.margin.toFixed(1)} 分，证据覆盖率 ${Math.round(result.recommendation.coverage * 100)}%。这是基于你设置的权重和输入的依据得到的暂定方向。`;
  } else if (result.status === 'needs-evidence') {
    label = 'MORE EVIDENCE NEEDED';
    name = '先补齐关键依据。';
    explanation = `领先方案是「${result.ranked[0].name}」，但证据覆盖率只有 ${Math.round(result.ranked[0].coverage * 100)}%。先验证权重较高的维度，再决定是否投入。`;
  } else {
    label = 'CLOSE CALL';
    name = '先验证关键假设。';
    explanation = `前两名只差 ${result.margin.toFixed(1)} 分。比起直接选第一名，更值得找出哪个假设改变后会翻转排序。`;
  }
  box.append(node('span', 'conclusion-label', label), node('div', 'conclusion-name', name), node('p', 'conclusion-explain', explanation));
  const metrics = node('div', 'conclusion-metrics');
  const margin = node('div');
  margin.append(node('strong', '', result.margin.toFixed(1)), node('span', '', '领先分差 / 5'));
  const coverage = node('div');
  coverage.append(node('strong', '', `${Math.round(result.ranked[0].coverage * 100)}%`), node('span', '', '领先方案证据覆盖率'));
  metrics.append(margin, coverage);
  box.append(metrics);
}

function render() {
  $('#question-title').textContent = state.title;
  $('#question-context').textContent = state.context;
  renderCriteria();
  renderResults();
  renderEvidence();
  renderConclusion();
}

$('#reset-example').addEventListener('click', () => {
  state = copySample();
  selectedId = state.options[0].id;
  saveState();
  render();
});

$('#download-report').addEventListener('click', () => {
  const result = evaluateDecision(state.criteria, state.options);
  const report = formatReport({ ...state, result });
  const url = URL.createObjectURL(new Blob([report], { type: 'text/markdown;charset=utf-8' }));
  const link = node('a');
  link.href = url;
  link.download = 'decision-notebook-report.md';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

render();
