export const sampleDecision = {
  title: '两周内改善团队知识查找，先做什么？',
  context: '情境设定：一个小团队的常用资料分散在多处，希望两周内让成员更快找到答案。以下评分与依据均为演示输入。',
  sample: true,
  criteria: [
    { id: 'value', label: '可验证价值', hint: '能否解决一个具体问题', weight: 4 },
    { id: 'delivery', label: '交付把握', hint: '两周内做出可用版本的可能性', weight: 3 },
    { id: 'clarity', label: '结果可理解性', hint: '团队能否理解使用方式与取舍', weight: 3 },
    { id: 'risk', label: '风险可控性', hint: '关键依赖是否掌握在自己手中', weight: 2 },
  ],
  options: [
    {
      id: 'tool',
      name: '聚焦高频问题的检索页',
      summary: '先整理常见问题并提供可搜索的最小入口。',
      scores: {
        value: { value: 5, evidence: '示例假设：团队有一批反复查询的常见问题。' },
        delivery: { value: 4, evidence: '示例计划：先收集高频问题并完成搜索与结果页。' },
        clarity: { value: 5, evidence: '搜索词、命中结果和资料来源都能直接看到。' },
        risk: { value: 4, evidence: '初版使用静态资料，无第三方 API 或复杂部署依赖。' },
      },
    },
    {
      id: 'platform',
      name: '功能丰富的知识平台',
      summary: '一次加入账号、仪表盘、协作和自动化整理。',
      scores: {
        value: { value: 2, evidence: '示例假设：新增功能尚未对应明确的团队需求。' },
        delivery: { value: 2, evidence: '两周内需要实现多条流程，测试范围较大。' },
        clarity: { value: 2, evidence: '功能多但核心问题不够集中。' },
        risk: { value: 2, evidence: '认证、数据存储和部署都增加不确定性。' },
      },
    },
    {
      id: 'case',
      name: '整理现有文档目录',
      summary: '统一资料命名、标签和入口页面，暂不提供搜索。',
      scores: {
        value: { value: 3, evidence: '示例假设：现有资料可用，但分散且命名不一致。' },
        delivery: { value: 5, evidence: '可从现有文档清单开始，先统一分类和入口。' },
        clarity: { value: 4, evidence: '目录结构和资料来源可以直接核对。' },
        risk: { value: 4, evidence: '主要风险是资料过期，整理时需要逐项确认。' },
      },
    },
  ],
};
