export const sampleDecision = {
  title: '两周内，先做哪种求职作品？',
  context: '情境设定：一个人只有两周时间，目标是让面试官迅速看懂解决问题和交付的能力。以下评分与依据均为演示输入。',
  sample: true,
  criteria: [
    { id: 'value', label: '可验证价值', hint: '能否解决一个具体问题', weight: 4 },
    { id: 'delivery', label: '交付把握', hint: '两周内做出可用版本的可能性', weight: 3 },
    { id: 'clarity', label: '表达清晰度', hint: '读者能否看懂过程与取舍', weight: 3 },
    { id: 'risk', label: '风险可控性', hint: '关键依赖是否掌握在自己手中', weight: 2 },
  ],
  options: [
    {
      id: 'tool',
      name: '聚焦一个真实问题的小工具',
      summary: '先做可用的最小版本，再公开设计取舍与测试结果。',
      scores: {
        value: { value: 5, evidence: '示例假设：问题可通过访谈或使用记录验证。' },
        delivery: { value: 4, evidence: '示例计划：功能范围限定为一条完整流程。' },
        clarity: { value: 5, evidence: '可展示输入、处理过程、输出和边界条件。' },
        risk: { value: 4, evidence: '无第三方 API、付费服务或复杂部署依赖。' },
      },
    },
    {
      id: 'platform',
      name: '功能丰富的完整平台',
      summary: '一次加入账号、仪表盘、协作和自动化功能。',
      scores: {
        value: { value: 2, evidence: '示例假设：新增功能尚未对应明确用户需求。' },
        delivery: { value: 2, evidence: '两周内需要实现多条流程，测试范围较大。' },
        clarity: { value: 2, evidence: '功能多但核心问题不够集中。' },
        risk: { value: 2, evidence: '认证、数据存储和部署都增加不确定性。' },
      },
    },
    {
      id: 'case',
      name: '项目案例型 README',
      summary: '把已有作品的目标、选择和证据整理成清晰的案例。',
      scores: {
        value: { value: 3, evidence: '示例假设：有已有作品，但缺少完整可操作演示。' },
        delivery: { value: 5, evidence: '材料可从现有代码、截图和记录中整理。' },
        clarity: { value: 4, evidence: '案例结构可以直接呈现问题、选择和结果。' },
        risk: { value: 4, evidence: '主要风险是原始材料不足，需如实注明。' },
      },
    },
  ],
};
