import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateDecision, formatReport } from '../src/decision.mjs';

const criteria = [
  { id: 'impact', label: '影响', weight: 3 },
  { id: 'effort', label: '投入效率', weight: 2 },
];

test('按权重计算方案分数，同时保留证据覆盖率', () => {
  const result = evaluateDecision(criteria, [
    { id: 'a', name: '方案 A', scores: { impact: { value: 5, evidence: '用户访谈' }, effort: { value: 2, evidence: '' } } },
    { id: 'b', name: '方案 B', scores: { impact: { value: 3, evidence: '试用记录' }, effort: { value: 4, evidence: '工时记录' } } },
  ]);

  assert.equal(result.ranked[0].id, 'a');
  assert.equal(result.ranked[0].score, 3.8);
  assert.equal(result.ranked[0].coverage, 0.6);
  assert.equal(result.ranked[1].score, 3.4);
  assert.equal(result.status, 'needs-evidence');
});

test('证据不足时不输出确定性推荐', () => {
  const result = evaluateDecision(criteria, [
    { id: 'a', name: '方案 A', scores: { impact: { value: 5, evidence: '' }, effort: { value: 5, evidence: '' } } },
    { id: 'b', name: '方案 B', scores: { impact: { value: 1, evidence: '' }, effort: { value: 1, evidence: '' } } },
  ]);

  assert.equal(result.status, 'needs-evidence');
  assert.equal(result.recommendation, null);
});

test('分数接近时提示比较关键假设', () => {
  const result = evaluateDecision(criteria, [
    { id: 'a', name: '方案 A', scores: { impact: { value: 4, evidence: '记录' }, effort: { value: 3, evidence: '记录' } } },
    { id: 'b', name: '方案 B', scores: { impact: { value: 3, evidence: '记录' }, effort: { value: 4, evidence: '记录' } } },
  ]);

  assert.equal(result.status, 'close-call');
  assert.equal(result.recommendation, null);
});

test('无效权重和分数会被拒绝', () => {
  assert.throws(() => evaluateDecision([{ id: 'x', weight: -1 }], [
    { id: 'a', name: 'A', scores: { x: { value: 3, evidence: '测试' } } },
  ]), /权重/);
  assert.throws(() => evaluateDecision([{ id: 'x', weight: 1 }], [
    { id: 'a', name: 'A', scores: { x: { value: 6, evidence: '测试' } } },
  ]), /分数/);
});

test('导出报告包含推荐条件与样本数据声明', () => {
  const options = [
    { id: 'a', name: '方案 A', scores: { impact: { value: 5, evidence: '访谈摘要' }, effort: { value: 5, evidence: '工时记录' } } },
    { id: 'b', name: '方案 B', scores: { impact: { value: 2, evidence: '访谈摘要' }, effort: { value: 2, evidence: '工时记录' } } },
  ];
  const result = evaluateDecision(criteria, options);
  const report = formatReport({ title: '先做什么？', criteria, options, result, sample: true });

  assert.match(report, /先做什么？/);
  assert.match(report, /方案 A/);
  assert.match(report, /访谈摘要/);
  assert.match(report, /示例数据/);
  assert.match(report, /权重/);
});
