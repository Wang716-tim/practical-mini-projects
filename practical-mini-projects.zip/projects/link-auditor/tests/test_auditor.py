import csv
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from link_auditor import audit_url, load_urls, write_report


class DemoHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        if self.path == "/get-only":
            self.send_response(405)
        elif self.path == "/moved":
            self.send_response(301)
            self.send_header("Location", "/ok")
        elif self.path == "/ok":
            self.send_response(200)
        else:
            self.send_response(404)
        self.end_headers()

    def do_GET(self):
        self.send_response(200 if self.path in ("/ok", "/get-only") else 404)
        self.end_headers()
        self.wfile.write(b"demo")

    def log_message(self, *_args):
        pass


class LinkAuditorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), DemoHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_load_urls_skips_comments_and_duplicates(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "urls.txt"
            path.write_text("# site\nhttps://example.com\n\nhttps://example.com\nhttp://example.com\n", encoding="utf-8")
            self.assertEqual(load_urls(path), ["https://example.com", "http://example.com"])

    def test_reports_ok_redirect_broken_and_get_fallback(self):
        self.assertEqual(audit_url(self.base + "/ok")["result"], "ok")
        moved = audit_url(self.base + "/moved")
        self.assertEqual(moved["result"], "redirected")
        self.assertTrue(moved["final_url"].endswith("/ok"))
        self.assertEqual(audit_url(self.base + "/missing")["status"], 404)
        self.assertEqual(audit_url(self.base + "/get-only")["result"], "ok")

    def test_rejects_non_http_urls_without_request(self):
        result = audit_url("file:///private/data")
        self.assertEqual(result["result"], "invalid")
        self.assertEqual(result["status"], "")
        self.assertEqual(audit_url("http://[bad")["result"], "invalid")

    def test_csv_report_preserves_fields(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "report.csv"
            write_report(path, [{"url": self.base + "/ok", "final_url": self.base + "/ok", "status": 200, "result": "ok", "duration_ms": 4, "note": "a,b"}])
            with path.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file))
            self.assertEqual(rows[0]["note"], "a,b")


if __name__ == "__main__":
    unittest.main()
