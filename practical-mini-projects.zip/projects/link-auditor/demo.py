"""A deterministic, offline demo of the link auditor."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread

from link_auditor import audit_url, write_report


class DemoHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        if self.path == "/moved":
            self.send_response(301)
            self.send_header("Location", "/ok")
        elif self.path == "/ok":
            self.send_response(200)
        else:
            self.send_response(404)
        self.end_headers()

    def do_GET(self):
        self.send_response(200 if self.path == "/ok" else 404)
        self.end_headers()
        self.wfile.write(b"demo")

    def log_message(self, *_args):
        pass


def main():
    server = ThreadingHTTPServer(("127.0.0.1", 0), DemoHandler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        base = f"http://127.0.0.1:{server.server_port}"
        rows = [audit_url(base + path) for path in ("/ok", "/moved", "/missing")]
        output = Path(__file__).with_name("demo-report.csv")
        write_report(output, rows)
        for row in rows:
            print(f"{row['result']:10} {row['status']:>3} {row['url']}")
        print(f"报告已保存：{output}")
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
